﻿namespace Admin_Baris_3_dan_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label4 = new Label();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            groupBox1 = new GroupBox();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            pictureBox10 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox8 = new PictureBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            nightControlBox1 = new ReaLTaiizor.Controls.NightControlBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(label4);
            panel1.Controls.Add(pictureBox7);
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(418, 1080);
            panel1.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 10.7999992F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(111, 296);
            label4.Name = "label4";
            label4.Size = new Size(203, 22);
            label4.TabIndex = 0;
            label4.Text = "jamaludin@gmail.com";
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = SystemColors.Highlight;
            pictureBox7.Image = Properties.Resources.Frame_15;
            pictureBox7.Location = new Point(32, 938);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(353, 63);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 0;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Frame_10__1_;
            pictureBox6.Location = new Point(32, 852);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(353, 63);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 0;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Group_237504;
            pictureBox5.Location = new Point(32, 598);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(353, 63);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 0;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Frame_11__1_;
            pictureBox4.Location = new Point(32, 392);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(353, 63);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 0;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Frame_17__1_;
            pictureBox3.Location = new Point(32, 497);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(353, 63);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(138, 249);
            label1.Name = "label1";
            label1.Size = new Size(154, 32);
            label1.TabIndex = 3;
            label1.Text = "Jamaludin";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Vector;
            pictureBox1.Location = new Point(111, 14);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(215, 232);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Dock = DockStyle.Top;
            pictureBox2.Image = Properties.Resources._20912_1__1_;
            pictureBox2.Location = new Point(418, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1502, 287);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Bold);
            label2.Location = new Point(455, 84);
            label2.Name = "label2";
            label2.Size = new Size(154, 32);
            label2.TabIndex = 3;
            label2.Text = "Jamaludin";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Bold);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(455, 23);
            label3.Name = "label3";
            label3.Size = new Size(237, 32);
            label3.TabIndex = 4;
            label3.Text = "Selamat datang,";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(pictureBox10);
            groupBox1.Controls.Add(pictureBox9);
            groupBox1.Controls.Add(pictureBox8);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.FlatStyle = FlatStyle.Flat;
            groupBox1.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Bold);
            groupBox1.Location = new Point(418, 317);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1484, 704);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "Daftar Peminjaman";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label16.ForeColor = SystemColors.ActiveBorder;
            label16.Location = new Point(1018, 341);
            label16.Name = "label16";
            label16.Size = new Size(93, 25);
            label16.TabIndex = 17;
            label16.Text = "4.25 AM";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label15.Location = new Point(1018, 311);
            label15.Name = "label15";
            label15.Size = new Size(146, 25);
            label15.TabIndex = 16;
            label15.Text = "03 April, 2024";
            label15.Click += label15_Click;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label14.ForeColor = SystemColors.ActiveBorder;
            label14.Location = new Point(1018, 223);
            label14.Name = "label14";
            label14.Size = new Size(92, 25);
            label14.TabIndex = 15;
            label14.Text = "7.30 PM";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label13.Location = new Point(1018, 193);
            label13.Name = "label13";
            label13.Size = new Size(146, 25);
            label13.TabIndex = 14;
            label13.Text = "02 April, 2024";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label12.ForeColor = SystemColors.ActiveBorder;
            label12.Location = new Point(1018, 97);
            label12.Name = "label12";
            label12.Size = new Size(93, 25);
            label12.TabIndex = 13;
            label12.Text = "4.25 AM";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label11.Location = new Point(1018, 67);
            label11.Name = "label11";
            label11.Size = new Size(146, 25);
            label11.TabIndex = 12;
            label11.Text = "02 April, 2024";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label10.ForeColor = SystemColors.ActiveBorder;
            label10.Location = new Point(148, 97);
            label10.Name = "label10";
            label10.Size = new Size(156, 25);
            label10.TabIndex = 11;
            label10.Text = "232410102065";
            label10.Click += label10_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label9.ForeColor = SystemColors.ActiveBorder;
            label9.Location = new Point(148, 223);
            label9.Name = "label9";
            label9.Size = new Size(156, 25);
            label9.TabIndex = 10;
            label9.Text = "232410102065";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label8.ForeColor = SystemColors.ActiveBorder;
            label8.Location = new Point(148, 341);
            label8.Name = "label8";
            label8.Size = new Size(156, 25);
            label8.TabIndex = 9;
            label8.Text = "232410102065";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label7.Location = new Point(148, 311);
            label7.Name = "label7";
            label7.Size = new Size(245, 25);
            label7.TabIndex = 8;
            label7.Text = "Moh Setiawan Wibisono";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label6.Location = new Point(148, 193);
            label6.Name = "label6";
            label6.Size = new Size(245, 25);
            label6.TabIndex = 7;
            label6.Text = "Moh Setiawan Wibisono";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            label5.Location = new Point(148, 67);
            label5.Name = "label5";
            label5.Size = new Size(245, 25);
            label5.TabIndex = 6;
            label5.Text = "Moh Setiawan Wibisono";
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Ellipse_12;
            pictureBox10.Location = new Point(37, 306);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(67, 70);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 5;
            pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.Ellipse_12;
            pictureBox9.Location = new Point(37, 187);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(67, 70);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 4;
            pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.Ellipse_12;
            pictureBox8.Location = new Point(37, 62);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(67, 70);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 3;
            pictureBox8.TabStop = false;
            // 
            // button3
            // 
            button3.Location = new Point(-6, 297);
            button3.Name = "button3";
            button3.Size = new Size(1484, 89);
            button3.TabIndex = 2;
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(0, 177);
            button2.Name = "button2";
            button2.Size = new Size(1484, 89);
            button2.TabIndex = 1;
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.Location = new Point(0, 52);
            button1.Name = "button1";
            button1.Size = new Size(1484, 89);
            button1.TabIndex = 0;
            button1.UseVisualStyleBackColor = true;
            button1.Click += this.button1_Click;
            // 
            // nightControlBox1
            // 
            nightControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            nightControlBox1.BackColor = Color.Transparent;
            nightControlBox1.CloseHoverColor = Color.FromArgb(199, 80, 80);
            nightControlBox1.CloseHoverForeColor = Color.White;
            nightControlBox1.DefaultLocation = true;
            nightControlBox1.DisableMaximizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.DisableMinimizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.EnableCloseColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMaximizeButton = true;
            nightControlBox1.EnableMaximizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMinimizeButton = true;
            nightControlBox1.EnableMinimizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.Location = new Point(1799, 0);
            nightControlBox1.MaximizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MaximizeHoverForeColor = Color.White;
            nightControlBox1.MinimizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MinimizeHoverForeColor = Color.White;
            nightControlBox1.Name = "nightControlBox1";
            nightControlBox1.Size = new Size(139, 31);
            nightControlBox1.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(1920, 1080);
            Controls.Add(nightControlBox1);
            Controls.Add(groupBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label3;
        private GroupBox groupBox1;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox7;
        private Label label4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Label label7;
        private Label label6;
        private Label label5;
        private PictureBox pictureBox10;
        private PictureBox pictureBox9;
        private PictureBox pictureBox8;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private ReaLTaiizor.Controls.NightControlBox nightControlBox1;
    }
}
