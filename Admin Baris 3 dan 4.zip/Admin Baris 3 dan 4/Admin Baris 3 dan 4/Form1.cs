namespace Admin_Baris_3_dan_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminBaris4 adminBaris4 = new AdminBaris4();
            adminBaris4.Show();
            this.Hide();
        }
    }

}
