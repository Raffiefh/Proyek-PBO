﻿namespace ProjectPBOFiturRegistrasi
{
    partial class DaftarAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            pictureBox3 = new PictureBox();
            label1 = new Label();
            bigTextBox1 = new ReaLTaiizor.Controls.BigTextBox();
            bigTextBox2 = new ReaLTaiizor.Controls.BigTextBox();
            bigTextBox3 = new ReaLTaiizor.Controls.BigTextBox();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.Highlight;
            pictureBox1.Location = new Point(0, -3);
            pictureBox1.Margin = new Padding(4, 4, 4, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(627, 1446);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.Highlight;
            pictureBox2.Image = Properties.Resources.Vector;
            pictureBox2.Location = new Point(168, 59);
            pictureBox2.Margin = new Padding(4, 4, 4, 4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(287, 267);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.HotTrack;
            button1.ForeColor = SystemColors.Control;
            button1.Location = new Point(53, 463);
            button1.Margin = new Padding(4, 4, 4, 4);
            button1.Name = "button1";
            button1.Size = new Size(516, 85);
            button1.TabIndex = 2;
            button1.Text = "Kelola Akun";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveCaptionText;
            button2.ForeColor = SystemColors.Control;
            button2.Location = new Point(53, 834);
            button2.Name = "button2";
            button2.Size = new Size(516, 80);
            button2.TabIndex = 3;
            button2.Text = "Profile";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.HotTrack;
            button3.Location = new Point(53, 946);
            button3.Name = "button3";
            button3.Size = new Size(516, 80);
            button3.TabIndex = 4;
            button3.Text = "Keluar";
            button3.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources._20912_2;
            pictureBox3.Location = new Point(626, -3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(1317, 255);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(653, 276);
            label1.Name = "label1";
            label1.Size = new Size(138, 28);
            label1.TabIndex = 6;
            label1.Text = "Daftar Admin";
            // 
            // bigTextBox1
            // 
            bigTextBox1.BackColor = Color.Transparent;
            bigTextBox1.Font = new Font("Nunito", 10.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bigTextBox1.ForeColor = Color.DimGray;
            bigTextBox1.Image = null;
            bigTextBox1.Location = new Point(679, 366);
            bigTextBox1.MaxLength = 32767;
            bigTextBox1.Multiline = false;
            bigTextBox1.Name = "bigTextBox1";
            bigTextBox1.ReadOnly = false;
            bigTextBox1.Size = new Size(1203, 46);
            bigTextBox1.TabIndex = 7;
            bigTextBox1.Text = "Username";
            bigTextBox1.TextAlignment = HorizontalAlignment.Left;
            bigTextBox1.UseSystemPasswordChar = false;
            // 
            // bigTextBox2
            // 
            bigTextBox2.BackColor = Color.Transparent;
            bigTextBox2.Font = new Font("Nunito", 10.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bigTextBox2.ForeColor = Color.DimGray;
            bigTextBox2.Image = null;
            bigTextBox2.Location = new Point(679, 435);
            bigTextBox2.MaxLength = 32767;
            bigTextBox2.Multiline = false;
            bigTextBox2.Name = "bigTextBox2";
            bigTextBox2.ReadOnly = false;
            bigTextBox2.Size = new Size(1203, 46);
            bigTextBox2.TabIndex = 8;
            bigTextBox2.Text = "No. Telepon";
            bigTextBox2.TextAlignment = HorizontalAlignment.Left;
            bigTextBox2.UseSystemPasswordChar = false;
            // 
            // bigTextBox3
            // 
            bigTextBox3.BackColor = Color.Transparent;
            bigTextBox3.Font = new Font("Nunito", 10.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bigTextBox3.ForeColor = Color.DimGray;
            bigTextBox3.Image = null;
            bigTextBox3.Location = new Point(679, 502);
            bigTextBox3.MaxLength = 32767;
            bigTextBox3.Multiline = false;
            bigTextBox3.Name = "bigTextBox3";
            bigTextBox3.ReadOnly = false;
            bigTextBox3.Size = new Size(1203, 46);
            bigTextBox3.TabIndex = 9;
            bigTextBox3.Text = "Password";
            bigTextBox3.TextAlignment = HorizontalAlignment.Left;
            bigTextBox3.UseSystemPasswordChar = false;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.HotTrack;
            button4.Location = new Point(1209, 962);
            button4.Name = "button4";
            button4.Size = new Size(210, 64);
            button4.TabIndex = 10;
            button4.Text = "Daftar Admin";
            button4.UseVisualStyleBackColor = false;
            // 
            // DaftarAdmin
            // 
            AutoScaleDimensions = new SizeF(12F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1942, 1102);
            Controls.Add(button4);
            Controls.Add(bigTextBox3);
            Controls.Add(bigTextBox2);
            Controls.Add(bigTextBox1);
            Controls.Add(label1);
            Controls.Add(pictureBox3);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Font = new Font("Nunito", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.Control;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 4, 4, 4);
            Name = "DaftarAdmin";
            Text = "DaftarAdmin";
            Load += DaftarAdmin_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Button button1;
        private Button button2;
        private Button button3;
        private PictureBox pictureBox3;
        private Label label1;
        private ReaLTaiizor.Controls.BigTextBox bigTextBox1;
        private ReaLTaiizor.Controls.BigTextBox bigTextBox2;
        private ReaLTaiizor.Controls.BigTextBox bigTextBox3;
        private Button button4;
    }
}