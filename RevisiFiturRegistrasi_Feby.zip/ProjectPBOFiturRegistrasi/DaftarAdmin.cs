﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPBOFiturRegistrasi
{
    public partial class DaftarAdmin : Form
    {
        public DaftarAdmin()
        {
            InitializeComponent();
        }

        private void DaftarAdmin_Load(object sender, EventArgs e)
        {

        }

        private void bigTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
