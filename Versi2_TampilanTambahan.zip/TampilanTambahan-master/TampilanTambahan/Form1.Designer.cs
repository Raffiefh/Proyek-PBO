﻿namespace TampilanTambahan
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            textBox1 = new TextBox();
            pictureBox4 = new PictureBox();
            label1 = new Label();
            pictureBox5 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            label4 = new Label();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            label5 = new Label();
            pictureBox11 = new PictureBox();
            pictureBox10 = new PictureBox();
            label6 = new Label();
            label8 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label7 = new Label();
            label9 = new Label();
            label10 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            SuspendLayout();
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.Control;
            pictureBox2.Image = Properties.Resources.Ellipse_12;
            pictureBox2.Location = new Point(12, 23);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(53, 54);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = SystemColors.Control;
            pictureBox3.Image = Properties.Resources.Layer_2;
            pictureBox3.Location = new Point(84, 23);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(21, 21);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.ControlLight;
            textBox1.Font = new Font("Nunito", 7.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(111, 23);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(1403, 36);
            textBox1.TabIndex = 3;
            textBox1.Text = " Follow You Home";
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = SystemColors.Control;
            pictureBox4.Image = Properties.Resources.Group;
            pictureBox4.Location = new Point(1763, 23);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(64, 42);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 4;
            pictureBox4.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nunito", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(39, 134);
            label1.Name = "label1";
            label1.Size = new Size(258, 44);
            label1.TabIndex = 5;
            label1.Text = "Selamat Datang,\r\n";
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = SystemColors.ControlLight;
            pictureBox5.Location = new Point(0, 96);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(1959, 10);
            pictureBox5.TabIndex = 6;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Nunito", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(289, 134);
            label2.Name = "label2";
            label2.Size = new Size(169, 44);
            label2.TabIndex = 7;
            label2.Text = "Jamaludin";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Nunito", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(39, 198);
            label3.Name = "label3";
            label3.Size = new Size(223, 40);
            label3.TabIndex = 8;
            label3.Text = "Paling Digemari";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Vector_1_;
            pictureBox1.Location = new Point(144, 241);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(18, 17);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Nunito", 10.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(39, 238);
            label4.Name = "label4";
            label4.Size = new Size(99, 37);
            label4.TabIndex = 10;
            label4.Text = "Favorit";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Group_237470;
            pictureBox6.Location = new Point(39, 294);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(625, 212);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 11;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.Group_237471;
            pictureBox7.Location = new Point(670, 294);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(625, 212);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 12;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.Frame_31;
            pictureBox8.Location = new Point(1747, 382);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(52, 52);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 13;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.Group_237470;
            pictureBox9.Location = new Point(1301, 294);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(395, 212);
            pictureBox9.TabIndex = 14;
            pictureBox9.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Nunito", 10.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(39, 576);
            label5.Name = "label5";
            label5.Size = new Size(253, 37);
            label5.TabIndex = 15;
            label5.Text = "Pilihan Untuk Kamu";
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = SystemColors.ButtonHighlight;
            pictureBox11.Location = new Point(84, 710);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(1743, 257);
            pictureBox11.TabIndex = 19;
            pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Group_237476_1_;
            pictureBox10.Location = new Point(39, 639);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(280, 329);
            pictureBox10.TabIndex = 20;
            pictureBox10.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Font = new Font("Nunito", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(361, 725);
            label6.Name = "label6";
            label6.Size = new Size(255, 40);
            label6.TabIndex = 21;
            label6.Text = "Follow You Home";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.ButtonHighlight;
            label8.Font = new Font("Nunito", 7.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(361, 782);
            label8.Name = "label8";
            label8.Size = new Size(1138, 145);
            label8.TabIndex = 22;
            label8.Text = resources.GetString("label8.Text");
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Highlight;
            button1.Font = new Font("Nunito", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(1648, 751);
            button1.Name = "button1";
            button1.Size = new Size(126, 48);
            button1.TabIndex = 23;
            button1.Text = "Baca";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Highlight;
            button2.Font = new Font("Nunito", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.ButtonHighlight;
            button2.Location = new Point(1621, 825);
            button2.Name = "button2";
            button2.Size = new Size(178, 51);
            button2.TabIndex = 24;
            button2.Text = "Pinjam";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.Highlight;
            button3.Font = new Font("Nunito", 7.124999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = SystemColors.ButtonHighlight;
            button3.Location = new Point(1631, 896);
            button3.Name = "button3";
            button3.Size = new Size(168, 44);
            button3.TabIndex = 25;
            button3.Text = "Selengkapnya";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(0, 0);
            label7.Name = "label7";
            label7.Size = new Size(78, 32);
            label7.TabIndex = 26;
            label7.Text = "label7";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Montserrat ExtraBold", 7.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = SystemColors.HotTrack;
            label9.Location = new Point(1575, 23);
            label9.Name = "label9";
            label9.Size = new Size(121, 29);
            label9.TabIndex = 27;
            label9.Text = "EZBRARY";
            label9.Click += label9_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Montserrat SemiBold", 7.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.LimeGreen;
            label10.Location = new Point(1544, 51);
            label10.Name = "label10";
            label10.Size = new Size(175, 26);
            label10.TabIndex = 28;
            label10.Text = "PERPUSTAKAAN";
            label10.UseMnemonic = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1940, 1080);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label7);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox11);
            Controls.Add(label5);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(label4);
            Controls.Add(pictureBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox5);
            Controls.Add(label1);
            Controls.Add(pictureBox4);
            Controls.Add(textBox1);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private TextBox textBox1;
        private PictureBox pictureBox4;
        private Label label1;
        private PictureBox pictureBox5;
        private Label label2;
        private Label label3;
        private PictureBox pictureBox1;
        private Label label4;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private Label label5;
        private PictureBox pictureBox11;
        private PictureBox pictureBox10;
        private Label label6;
        private Label label8;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label7;
        private Label label9;
        private Label label10;
    }
}
