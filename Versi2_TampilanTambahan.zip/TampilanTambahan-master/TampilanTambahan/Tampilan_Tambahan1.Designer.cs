﻿namespace TampilanTambahan
{
    partial class Tampilan_Tambahan1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tampilan_Tambahan1));
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            textBox1 = new TextBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            label2 = new Label();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox12 = new PictureBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            pictureBox13 = new PictureBox();
            pictureBox14 = new PictureBox();
            pictureBox15 = new PictureBox();
            pictureBox16 = new PictureBox();
            pictureBox17 = new PictureBox();
            pictureBox18 = new PictureBox();
            pictureBox19 = new PictureBox();
            pictureBox20 = new PictureBox();
            label16 = new Label();
            label17 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ControlLight;
            pictureBox1.Location = new Point(0, 96);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1940, 10);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Ellipse_12;
            pictureBox2.Location = new Point(12, 23);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(53, 54);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Layer_2;
            pictureBox3.Location = new Point(83, 23);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(21, 21);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Group;
            pictureBox4.Location = new Point(1763, 23);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(64, 42);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 3;
            pictureBox4.TabStop = false;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.ControlLight;
            textBox1.Font = new Font("Nunito", 7.124999F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(111, 23);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(1403, 33);
            textBox1.TabIndex = 4;
            textBox1.Text = " Follow You Home ";
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Group_237476_1_;
            pictureBox5.Location = new Point(484, 123);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(250, 293);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 5;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = SystemColors.ControlLight;
            pictureBox6.Location = new Point(-5, 422);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(1945, 10);
            pictureBox6.TabIndex = 6;
            pictureBox6.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nunito", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(894, 137);
            label1.Name = "label1";
            label1.Size = new Size(280, 44);
            label1.TabIndex = 7;
            label1.Text = "Follow You Home";
            label1.Click += label1_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Highlight;
            button1.Font = new Font("Nunito", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(894, 341);
            button1.Name = "button1";
            button1.Size = new Size(126, 48);
            button1.TabIndex = 8;
            button1.Text = "Baca";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Highlight;
            button2.Font = new Font("Nunito", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.ButtonHighlight;
            button2.Location = new Point(1091, 341);
            button2.Name = "button2";
            button2.Size = new Size(126, 48);
            button2.TabIndex = 9;
            button2.Text = "Pinjam";
            button2.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Nunito", 7.124999F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(97, 461);
            label2.Name = "label2";
            label2.Size = new Size(811, 182);
            label2.TabIndex = 10;
            label2.Text = resources.GetString("label2.Text");
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.Group_237477_1_;
            pictureBox7.Location = new Point(120, 664);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(82, 37);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 11;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.Group_237477_1_;
            pictureBox8.Location = new Point(244, 664);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(81, 37);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 12;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.Rectangle_1179_1_;
            pictureBox9.Location = new Point(1287, 461);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(641, 652);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 13;
            pictureBox9.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = SystemColors.ButtonHighlight;
            pictureBox11.Location = new Point(38, 722);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(1205, 326);
            pictureBox11.TabIndex = 15;
            pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = SystemColors.ButtonHighlight;
            pictureBox10.Image = Properties.Resources.Group_237471;
            pictureBox10.Location = new Point(1397, 621);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(447, 178);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 16;
            pictureBox10.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = SystemColors.ButtonHighlight;
            pictureBox12.Image = Properties.Resources.Group_237471;
            pictureBox12.Location = new Point(1397, 819);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(447, 178);
            pictureBox12.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox12.TabIndex = 17;
            pictureBox12.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Font = new Font("Nunito", 8.999998F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(1349, 510);
            label3.Name = "label3";
            label3.Size = new Size(203, 33);
            label3.TabIndex = 18;
            label3.Text = "Kamu Pasti Suka";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Font = new Font("Nunito", 8.999998F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(62, 740);
            label4.Name = "label4";
            label4.Size = new Size(118, 33);
            label4.TabIndex = 19;
            label4.Text = "Daftar Isi";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ButtonHighlight;
            label5.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(62, 804);
            label5.Name = "label5";
            label5.Size = new Size(128, 33);
            label5.TabIndex = 20;
            label5.Text = "Pengantar";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(62, 846);
            label6.Name = "label6";
            label6.Size = new Size(86, 33);
            label6.TabIndex = 21;
            label6.Text = "Prolog";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ButtonHighlight;
            label7.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(62, 879);
            label7.Name = "label7";
            label7.Size = new Size(226, 33);
            label7.TabIndex = 22;
            label7.Text = "Chapter 1 - Collage";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.ButtonHighlight;
            label8.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(62, 921);
            label8.Name = "label8";
            label8.Size = new Size(201, 33);
            label8.TabIndex = 23;
            label8.Text = "Chapter 2 - Party";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.ButtonHighlight;
            label9.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(65, 964);
            label9.Name = "label9";
            label9.Size = new Size(223, 33);
            label9.TabIndex = 24;
            label9.Text = "Chapter 3 - Really?";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = SystemColors.ButtonHighlight;
            label10.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(1132, 753);
            label10.Name = "label10";
            label10.Size = new Size(53, 33);
            label10.TabIndex = 25;
            label10.Text = "Hal";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = SystemColors.ButtonHighlight;
            label11.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(1145, 804);
            label11.Name = "label11";
            label11.Size = new Size(29, 33);
            label11.TabIndex = 26;
            label11.Text = "1";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = SystemColors.ButtonHighlight;
            label12.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(1145, 837);
            label12.Name = "label12";
            label12.Size = new Size(29, 33);
            label12.TabIndex = 27;
            label12.Text = "3";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = SystemColors.ButtonHighlight;
            label13.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.Location = new Point(1145, 879);
            label13.Name = "label13";
            label13.Size = new Size(29, 33);
            label13.TabIndex = 28;
            label13.Text = "4";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = SystemColors.ButtonHighlight;
            label14.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.Location = new Point(1145, 921);
            label14.Name = "label14";
            label14.Size = new Size(29, 33);
            label14.TabIndex = 29;
            label14.Text = "7";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = SystemColors.ButtonHighlight;
            label15.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label15.Location = new Point(1145, 964);
            label15.Name = "label15";
            label15.Size = new Size(29, 33);
            label15.TabIndex = 30;
            label15.Text = "9";
            // 
            // pictureBox13
            // 
            pictureBox13.Image = Properties.Resources.Group_237482;
            pictureBox13.Location = new Point(867, 209);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(80, 24);
            pictureBox13.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox13.TabIndex = 31;
            pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = Properties.Resources.Group_237481;
            pictureBox14.Location = new Point(992, 211);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(79, 22);
            pictureBox14.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox14.TabIndex = 32;
            pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            pictureBox15.Image = Properties.Resources.Group_237483;
            pictureBox15.Location = new Point(1132, 213);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(62, 22);
            pictureBox15.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox15.TabIndex = 33;
            pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            pictureBox16.Image = Properties.Resources._1M;
            pictureBox16.Location = new Point(894, 249);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(24, 22);
            pictureBox16.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox16.TabIndex = 34;
            pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            pictureBox17.Image = Properties.Resources._50K;
            pictureBox17.Location = new Point(1022, 249);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new Size(28, 22);
            pictureBox17.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox17.TabIndex = 35;
            pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            pictureBox18.Image = Properties.Resources._47;
            pictureBox18.Location = new Point(1150, 249);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new Size(24, 22);
            pictureBox18.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox18.TabIndex = 36;
            pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            pictureBox19.Image = Properties.Resources.Rectangle_1175;
            pictureBox19.Location = new Point(969, 211);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new Size(1, 60);
            pictureBox19.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox19.TabIndex = 37;
            pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            pictureBox20.Image = Properties.Resources.Rectangle_1175;
            pictureBox20.Location = new Point(1108, 211);
            pictureBox20.Name = "pictureBox20";
            pictureBox20.Size = new Size(1, 60);
            pictureBox20.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox20.TabIndex = 38;
            pictureBox20.TabStop = false;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Montserrat", 7.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = SystemColors.HotTrack;
            label16.Location = new Point(1575, 23);
            label16.Name = "label16";
            label16.Size = new Size(117, 29);
            label16.TabIndex = 39;
            label16.Text = "EZBRARY";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Montserrat Medium", 7.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = Color.LimeGreen;
            label17.Location = new Point(1544, 51);
            label17.Name = "label17";
            label17.Size = new Size(175, 26);
            label17.TabIndex = 40;
            label17.Text = "PERPUSTAKAAN";
            // 
            // Tampilan_Tambahan1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1940, 1009);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(pictureBox20);
            Controls.Add(pictureBox19);
            Controls.Add(pictureBox18);
            Controls.Add(pictureBox17);
            Controls.Add(pictureBox16);
            Controls.Add(pictureBox15);
            Controls.Add(pictureBox14);
            Controls.Add(pictureBox13);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(textBox1);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Tampilan_Tambahan1";
            Text = "Tampilan_Tambahan1";
            Load += Tampilan_Tambahan1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private TextBox textBox1;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Label label1;
        private Button button1;
        private Button button2;
        private Label label2;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox11;
        private PictureBox pictureBox10;
        private PictureBox pictureBox12;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private PictureBox pictureBox13;
        private PictureBox pictureBox14;
        private PictureBox pictureBox15;
        private PictureBox pictureBox16;
        private PictureBox pictureBox17;
        private PictureBox pictureBox18;
        private PictureBox pictureBox19;
        private PictureBox pictureBox20;
        private Label label16;
        private Label label17;
    }
}