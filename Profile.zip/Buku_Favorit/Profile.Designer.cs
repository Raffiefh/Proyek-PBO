﻿namespace Buku_Favorit
{
    partial class Profile
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            label3 = new Label();
            label2 = new Label();
            button6 = new Button();
            pictureBox1 = new PictureBox();
            bigLabel1 = new ReaLTaiizor.Controls.BigLabel();
            panel2 = new Panel();
            bigLabel2 = new ReaLTaiizor.Controls.BigLabel();
            label1 = new Label();
            groupBox1 = new GroupBox();
            button1 = new Button();
            textBox1 = new TextBox();
            groupBox2 = new GroupBox();
            button2 = new Button();
            textBox2 = new TextBox();
            groupBox3 = new GroupBox();
            button3 = new Button();
            textBox3 = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(-7, -5);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(418, 1062);
            panel1.TabIndex = 0;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Frame_17__1_;
            pictureBox6.Location = new Point(23, 400);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(368, 74);
            pictureBox6.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox6.TabIndex = 11;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Frame_19;
            pictureBox5.Location = new Point(18, 549);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(380, 76);
            pictureBox5.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox5.TabIndex = 13;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Frame_15;
            pictureBox4.Location = new Point(22, 952);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(376, 76);
            pictureBox4.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox4.TabIndex = 12;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Frame_11;
            pictureBox3.Location = new Point(29, 473);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(356, 76);
            pictureBox3.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox3.TabIndex = 11;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Frame_10;
            pictureBox2.Location = new Point(29, 889);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(364, 64);
            pictureBox2.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox2.TabIndex = 11;
            pictureBox2.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Nunito SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.Control;
            label3.Location = new Point(122, 316);
            label3.Name = "label3";
            label3.Size = new Size(182, 23);
            label3.TabIndex = 9;
            label3.Text = "jamaludin@gmail.com";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Nunito", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(151, 287);
            label2.Name = "label2";
            label2.Size = new Size(121, 32);
            label2.TabIndex = 8;
            label2.Text = "Jamaludin";
            label2.Click += label2_Click;
            // 
            // button6
            // 
            button6.Location = new Point(90, 1177);
            button6.Margin = new Padding(3, 4, 3, 4);
            button6.Name = "button6";
            button6.Size = new Size(367, 68);
            button6.TabIndex = 6;
            button6.Text = "button6";
            button6.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Ellipse_11;
            pictureBox1.Location = new Point(113, 76);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(195, 192);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // bigLabel1
            // 
            bigLabel1.AutoSize = true;
            bigLabel1.BackColor = Color.Transparent;
            bigLabel1.Font = new Font("Nunito", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bigLabel1.ForeColor = Color.White;
            bigLabel1.Location = new Point(26, 23);
            bigLabel1.Name = "bigLabel1";
            bigLabel1.Size = new Size(251, 41);
            bigLabel1.TabIndex = 10;
            bigLabel1.Text = "Selamat Datang,";
            bigLabel1.Click += bigLabel1_Click;
            // 
            // panel2
            // 
            panel2.BackgroundImage = Properties.Resources._20912_1;
            panel2.Controls.Add(bigLabel2);
            panel2.Controls.Add(bigLabel1);
            panel2.Location = new Point(411, -1);
            panel2.Name = "panel2";
            panel2.Size = new Size(1484, 287);
            panel2.TabIndex = 2;
            panel2.Paint += panel2_Paint;
            // 
            // bigLabel2
            // 
            bigLabel2.AutoSize = true;
            bigLabel2.BackColor = Color.Transparent;
            bigLabel2.Font = new Font("Nunito ExtraBold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bigLabel2.ForeColor = Color.White;
            bigLabel2.Location = new Point(26, 56);
            bigLabel2.Name = "bigLabel2";
            bigLabel2.Size = new Size(162, 41);
            bigLabel2.TabIndex = 11;
            bigLabel2.Text = "Jamaludin";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nunito", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(431, 311);
            label1.Name = "label1";
            label1.Size = new Size(62, 23);
            label1.TabIndex = 14;
            label1.Text = "Profile";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Font = new Font("Nunito SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(431, 363);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(968, 91);
            groupBox1.TabIndex = 15;
            groupBox1.TabStop = false;
            groupBox1.Text = "Nama";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.HotTrack;
            button1.FlatAppearance.BorderColor = SystemColors.HotTrack;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = SystemColors.Control;
            button1.Location = new Point(802, 32);
            button1.Name = "button1";
            button1.Size = new Size(95, 29);
            button1.TabIndex = 1;
            button1.Text = "Ubah";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.HotTrack;
            textBox1.ForeColor = SystemColors.Control;
            textBox1.Location = new Point(25, 31);
            textBox1.MinimumSize = new Size(2, 3);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(771, 31);
            textBox1.TabIndex = 0;
            textBox1.Text = "Jamaludin";
            textBox1.TextChanged += textBox1_TextChanged_1;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(textBox2);
            groupBox2.Location = new Point(431, 460);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(962, 84);
            groupBox2.TabIndex = 16;
            groupBox2.TabStop = false;
            groupBox2.Text = "Email";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.HotTrack;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Nunito SemiBold", 10.7999992F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.Control;
            button2.Location = new Point(802, 32);
            button2.Name = "button2";
            button2.Size = new Size(95, 31);
            button2.TabIndex = 1;
            button2.Text = "Ubah";
            button2.UseVisualStyleBackColor = false;
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.HotTrack;
            textBox2.Font = new Font("Nunito SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox2.ForeColor = SystemColors.Control;
            textBox2.Location = new Point(25, 31);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(771, 31);
            textBox2.TabIndex = 0;
            textBox2.Text = "jamaludin@gmail.com";
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(button3);
            groupBox3.Controls.Add(textBox3);
            groupBox3.Location = new Point(431, 550);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(962, 95);
            groupBox3.TabIndex = 17;
            groupBox3.TabStop = false;
            groupBox3.Text = "No. Telepon";
            // 
            // button3
            // 
            button3.BackColor = SystemColors.HotTrack;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Nunito SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = SystemColors.Control;
            button3.Location = new Point(802, 32);
            button3.Name = "button3";
            button3.Size = new Size(95, 29);
            button3.TabIndex = 2;
            button3.Text = "Ubah";
            button3.UseVisualStyleBackColor = false;
            // 
            // textBox3
            // 
            textBox3.BackColor = SystemColors.HotTrack;
            textBox3.Font = new Font("Nunito SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox3.ForeColor = SystemColors.Control;
            textBox3.Location = new Point(25, 31);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(771, 31);
            textBox3.TabIndex = 0;
            textBox3.Text = "082163817387";
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1924, 1055);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Font = new Font("Nunito", 10.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ControlDark;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private Button button6;
        private Label label2;
        private Label label3;
        private ReaLTaiizor.Controls.BigLabel bigLabel1;
        private Panel panel2;
        private ReaLTaiizor.Controls.BigLabel bigLabel2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Label label1;
        private GroupBox groupBox1;
        private Button button1;
        public TextBox textBox1;
        private GroupBox groupBox2;
        private TextBox textBox2;
        private Button button2;
        private GroupBox groupBox3;
        private Button button3;
        private TextBox textBox3;
    }
}
