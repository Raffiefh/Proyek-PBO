﻿namespace ProjectPBOFiturRegistrasi
{
    partial class Masuk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            bigTextBox1 = new ReaLTaiizor.Controls.BigTextBox();
            bigTextBox2 = new ReaLTaiizor.Controls.BigTextBox();
            bigTextBox3 = new ReaLTaiizor.Controls.BigTextBox();
            bigTextBox4 = new ReaLTaiizor.Controls.BigTextBox();
            bigTextBox5 = new ReaLTaiizor.Controls.BigTextBox();
            button1 = new Button();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            linkLabel1 = new LinkLabel();
            pictureBox3 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Mask_group;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(609, 263);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // bigTextBox1
            // 
            bigTextBox1.BackColor = Color.Transparent;
            bigTextBox1.Font = new Font("Nunito", 10.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bigTextBox1.ForeColor = Color.DimGray;
            bigTextBox1.Image = null;
            bigTextBox1.Location = new Point(88, 311);
            bigTextBox1.MaxLength = 32767;
            bigTextBox1.Multiline = false;
            bigTextBox1.Name = "bigTextBox1";
            bigTextBox1.ReadOnly = false;
            bigTextBox1.Size = new Size(437, 48);
            bigTextBox1.TabIndex = 1;
            bigTextBox1.Text = "Username";
            bigTextBox1.TextAlignment = HorizontalAlignment.Left;
            bigTextBox1.UseSystemPasswordChar = false;
            // 
            // bigTextBox2
            // 
            bigTextBox2.BackColor = Color.Transparent;
            bigTextBox2.Font = new Font("Nunito", 10.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bigTextBox2.ForeColor = Color.DimGray;
            bigTextBox2.Image = null;
            bigTextBox2.Location = new Point(88, 382);
            bigTextBox2.MaxLength = 32767;
            bigTextBox2.Multiline = false;
            bigTextBox2.Name = "bigTextBox2";
            bigTextBox2.ReadOnly = false;
            bigTextBox2.Size = new Size(437, 48);
            bigTextBox2.TabIndex = 2;
            bigTextBox2.Text = "Nama";
            bigTextBox2.TextAlignment = HorizontalAlignment.Left;
            bigTextBox2.UseSystemPasswordChar = false;
            // 
            // bigTextBox3
            // 
            bigTextBox3.BackColor = Color.Transparent;
            bigTextBox3.Font = new Font("Nunito", 10.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bigTextBox3.ForeColor = Color.DimGray;
            bigTextBox3.Image = null;
            bigTextBox3.Location = new Point(88, 453);
            bigTextBox3.MaxLength = 32767;
            bigTextBox3.Multiline = false;
            bigTextBox3.Name = "bigTextBox3";
            bigTextBox3.ReadOnly = false;
            bigTextBox3.Size = new Size(437, 48);
            bigTextBox3.TabIndex = 4;
            bigTextBox3.Text = "No. Telepon";
            bigTextBox3.TextAlignment = HorizontalAlignment.Left;
            bigTextBox3.UseSystemPasswordChar = false;
            // 
            // bigTextBox4
            // 
            bigTextBox4.BackColor = Color.Transparent;
            bigTextBox4.Font = new Font("Nunito", 10.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bigTextBox4.ForeColor = Color.DimGray;
            bigTextBox4.Image = null;
            bigTextBox4.Location = new Point(88, 520);
            bigTextBox4.MaxLength = 32767;
            bigTextBox4.Multiline = false;
            bigTextBox4.Name = "bigTextBox4";
            bigTextBox4.ReadOnly = false;
            bigTextBox4.Size = new Size(437, 48);
            bigTextBox4.TabIndex = 5;
            bigTextBox4.Text = "Password";
            bigTextBox4.TextAlignment = HorizontalAlignment.Left;
            bigTextBox4.UseSystemPasswordChar = false;
            // 
            // bigTextBox5
            // 
            bigTextBox5.BackColor = Color.Transparent;
            bigTextBox5.Font = new Font("Nunito", 10.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            bigTextBox5.ForeColor = Color.DimGray;
            bigTextBox5.Image = null;
            bigTextBox5.Location = new Point(88, 597);
            bigTextBox5.MaxLength = 32767;
            bigTextBox5.Multiline = false;
            bigTextBox5.Name = "bigTextBox5";
            bigTextBox5.ReadOnly = false;
            bigTextBox5.Size = new Size(437, 48);
            bigTextBox5.TabIndex = 6;
            bigTextBox5.Text = "Masukkan Kembali Password";
            bigTextBox5.TextAlignment = HorizontalAlignment.Left;
            bigTextBox5.UseSystemPasswordChar = false;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.HotTrack;
            button1.Font = new Font("Nunito", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.Control;
            button1.Location = new Point(122, 720);
            button1.Name = "button1";
            button1.Size = new Size(349, 52);
            button1.TabIndex = 7;
            button1.Text = "Daftar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nunito", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlDarkDark;
            label1.Location = new Point(227, 944);
            label1.Name = "label1";
            label1.Size = new Size(144, 20);
            label1.TabIndex = 8;
            label1.Text = "Sudah Punya Akun?";
            label1.Click += label1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Group_237532_1_;
            pictureBox2.Location = new Point(524, 944);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(44, 36);
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(268, 964);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(51, 20);
            linkLabel1.TabIndex = 10;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Masuk";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Group;
            pictureBox3.Location = new Point(1115, 362);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(313, 204);
            pictureBox3.TabIndex = 11;
            pictureBox3.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Montserrat ExtraBold", 19.7999973F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.HotTrack;
            label2.Location = new Point(1190, 569);
            label2.Name = "label2";
            label2.Size = new Size(186, 46);
            label2.TabIndex = 12;
            label2.Text = "EZBRARY";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Montserrat Medium", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.LimeGreen;
            label3.ImageAlign = ContentAlignment.MiddleRight;
            label3.Location = new Point(1150, 615);
            label3.Name = "label3";
            label3.Size = new Size(264, 39);
            label3.TabIndex = 13;
            label3.Text = "PERPUSTAKAAN";
            // 
            // Masuk
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1902, 1033);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox3);
            Controls.Add(linkLabel1);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(bigTextBox5);
            Controls.Add(bigTextBox4);
            Controls.Add(bigTextBox3);
            Controls.Add(bigTextBox2);
            Controls.Add(bigTextBox1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Masuk";
            Text = "m                                   ";
            Load += Masuk_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private ReaLTaiizor.Controls.BigTextBox bigTextBox1;
        private ReaLTaiizor.Controls.BigTextBox bigTextBox2;
        private ReaLTaiizor.Controls.BigTextBox bigTextBox3;
        private ReaLTaiizor.Controls.BigTextBox bigTextBox4;
        private ReaLTaiizor.Controls.BigTextBox bigTextBox5;
        private Button button1;
        private Label label1;
        private PictureBox pictureBox2;
        private LinkLabel linkLabel1;
        private PictureBox pictureBox3;
        private Label label2;
        private Label label3;
    }
}