﻿namespace FiturAdmin
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            label4 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            label3 = new Label();
            label2 = new Label();
            nightControlBox1 = new ReaLTaiizor.Controls.NightControlBox();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            groupBox1 = new GroupBox();
            pictureBox11 = new PictureBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            label7 = new Label();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            label6 = new Label();
            textBox1 = new TextBox();
            label5 = new Label();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(pictureBox7);
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(418, 1033);
            panel1.TabIndex = 3;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.Frame_15;
            pictureBox7.Location = new Point(32, 938);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(353, 63);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 7;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Frame_10;
            pictureBox6.Location = new Point(32, 852);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(353, 63);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 7;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Group_237504__1_;
            pictureBox5.Location = new Point(32, 598);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(353, 63);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 7;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Frame_23;
            pictureBox4.Location = new Point(32, 497);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(353, 63);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 7;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Frame_11;
            pictureBox3.Location = new Point(32, 392);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(353, 63);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 7;
            pictureBox3.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Nunito", 10.7999992F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(111, 296);
            label4.Name = "label4";
            label4.Size = new Size(197, 24);
            label4.TabIndex = 6;
            label4.Text = "jamaludin@gmail.com";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nunito", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(138, 249);
            label1.Name = "label1";
            label1.Size = new Size(147, 38);
            label1.TabIndex = 3;
            label1.Text = "Jamaludin";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Vector;
            pictureBox1.Location = new Point(102, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(215, 232);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Dock = DockStyle.Top;
            pictureBox2.Image = Properties.Resources._20912_1;
            pictureBox2.Location = new Point(418, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1484, 287);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Nunito Medium", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(457, 23);
            label3.Name = "label3";
            label3.Size = new Size(224, 38);
            label3.TabIndex = 7;
            label3.Text = "Selamat datang,";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Nunito", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(457, 86);
            label2.Name = "label2";
            label2.Size = new Size(147, 38);
            label2.TabIndex = 8;
            label2.Text = "Jamaludin";
            label2.Click += label2_Click;
            // 
            // nightControlBox1
            // 
            nightControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            nightControlBox1.BackColor = Color.Transparent;
            nightControlBox1.CloseHoverColor = Color.FromArgb(199, 80, 80);
            nightControlBox1.CloseHoverForeColor = Color.White;
            nightControlBox1.DefaultLocation = true;
            nightControlBox1.DisableMaximizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.DisableMinimizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.EnableCloseColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMaximizeButton = true;
            nightControlBox1.EnableMaximizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMinimizeButton = true;
            nightControlBox1.EnableMinimizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.Location = new Point(1763, 0);
            nightControlBox1.MaximizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MaximizeHoverForeColor = Color.White;
            nightControlBox1.MinimizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MinimizeHoverForeColor = Color.White;
            nightControlBox1.Name = "nightControlBox1";
            nightControlBox1.Size = new Size(139, 31);
            nightControlBox1.TabIndex = 9;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.Frame_45;
            pictureBox8.Location = new Point(418, 285);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(157, 42);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 10;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.Frame_46;
            pictureBox9.Location = new Point(581, 285);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(201, 42);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 11;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Frame_47;
            pictureBox10.Location = new Point(788, 285);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(171, 42);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 12;
            pictureBox10.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.Controls.Add(textBox9);
            groupBox1.Controls.Add(textBox10);
            groupBox1.Controls.Add(textBox7);
            groupBox1.Controls.Add(textBox8);
            groupBox1.Controls.Add(pictureBox11);
            groupBox1.Controls.Add(textBox5);
            groupBox1.Controls.Add(textBox6);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label5);
            groupBox1.Font = new Font("Nunito", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(418, 329);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1484, 704);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = Properties.Resources.Frame_15__1_;
            pictureBox11.Location = new Point(584, 609);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(353, 63);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 24;
            pictureBox11.TabStop = false;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox5.Location = new Point(18, 369);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(1442, 31);
            textBox5.TabIndex = 23;
            textBox5.Text = "Kode Buku";
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox6.Location = new Point(18, 322);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(1442, 31);
            textBox6.TabIndex = 22;
            textBox6.Text = "Judul Buku";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Nunito Medium", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(18, 296);
            label7.Name = "label7";
            label7.Size = new Size(166, 23);
            label7.TabIndex = 21;
            label7.Text = "Buku yang Dipinjam";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(18, 228);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(1442, 31);
            textBox4.TabIndex = 20;
            textBox4.Text = "Alamat";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(18, 176);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(1442, 31);
            textBox3.TabIndex = 19;
            textBox3.Text = "No. Telepon";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(18, 129);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(1442, 31);
            textBox2.TabIndex = 18;
            textBox2.Text = "Nama Lengkap";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Nunito Medium", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(18, 103);
            label6.Name = "label6";
            label6.Size = new Size(121, 23);
            label6.TabIndex = 17;
            label6.Text = "Informasi User";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(18, 39);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(1442, 31);
            textBox1.TabIndex = 16;
            textBox1.Text = "ID User";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Nunito Medium", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(18, 13);
            label5.Name = "label5";
            label5.Size = new Size(66, 23);
            label5.TabIndex = 14;
            label5.Text = "ID User";
            // 
            // textBox7
            // 
            textBox7.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox7.Location = new Point(18, 464);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(1442, 31);
            textBox7.TabIndex = 26;
            textBox7.Text = "Tanggal Jatuh Tempo";
            // 
            // textBox8
            // 
            textBox8.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox8.Location = new Point(18, 417);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(1442, 31);
            textBox8.TabIndex = 25;
            textBox8.Text = "Tanggal Peminjaman";
            // 
            // textBox9
            // 
            textBox9.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox9.Location = new Point(18, 561);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(1442, 31);
            textBox9.TabIndex = 28;
            textBox9.Text = "Denda";
            // 
            // textBox10
            // 
            textBox10.Font = new Font("Nunito", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox10.Location = new Point(18, 514);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(1442, 31);
            textBox10.TabIndex = 27;
            textBox10.Text = "Pengembalian";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1902, 1033);
            Controls.Add(groupBox1);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(nightControlBox1);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(pictureBox2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form3";
            Text = "Form3";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Label label4;
        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label3;
        private Label label2;
        private ReaLTaiizor.Controls.NightControlBox nightControlBox1;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private GroupBox groupBox1;
        private PictureBox pictureBox11;
        private TextBox textBox5;
        private TextBox textBox6;
        private Label label7;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private Label label6;
        private TextBox textBox1;
        private Label label5;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
    }
}