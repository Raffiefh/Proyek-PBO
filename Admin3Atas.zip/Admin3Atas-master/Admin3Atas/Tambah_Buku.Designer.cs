﻿namespace Admin3Atas
{
    partial class Tambah_Buku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            Jamaludin = new Label();
            label2 = new Label();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox11 = new PictureBox();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            pictureBox12 = new PictureBox();
            label5 = new Label();
            button1 = new Button();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            pictureBox13 = new PictureBox();
            pictureBox14 = new PictureBox();
            label16 = new Label();
            label17 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.Highlight;
            pictureBox1.Dock = DockStyle.Left;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(418, 1080);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Dock = DockStyle.Top;
            pictureBox2.Image = Properties.Resources.Mask_group;
            pictureBox2.Location = new Point(418, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1502, 439);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = SystemColors.Highlight;
            pictureBox3.Image = Properties.Resources.Vector;
            pictureBox3.Location = new Point(80, 41);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(245, 179);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = SystemColors.Highlight;
            pictureBox4.Image = Properties.Resources.Frame_10;
            pictureBox4.Location = new Point(34, 834);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(344, 61);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 3;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Frame_11;
            pictureBox5.Location = new Point(34, 353);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(344, 61);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 4;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Frame_15;
            pictureBox6.Location = new Point(34, 916);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(344, 61);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 5;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.Frame_17;
            pictureBox7.Location = new Point(34, 443);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(344, 61);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 6;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.Group_237503;
            pictureBox8.Location = new Point(34, 538);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(344, 61);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 7;
            pictureBox8.TabStop = false;
            // 
            // Jamaludin
            // 
            Jamaludin.AutoSize = true;
            Jamaludin.BackColor = SystemColors.Highlight;
            Jamaludin.Font = new Font("Nunito", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Jamaludin.Location = new Point(116, 246);
            Jamaludin.Name = "Jamaludin";
            Jamaludin.Size = new Size(169, 44);
            Jamaludin.TabIndex = 8;
            Jamaludin.Text = "Jamaludin";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.Highlight;
            label2.Font = new Font("Nunito", 7.124999F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.HighlightText;
            label2.Location = new Point(96, 290);
            label2.Name = "label2";
            label2.Size = new Size(200, 26);
            label2.TabIndex = 9;
            label2.Text = "jamaludin@gamil.com";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.Rectangle_1177;
            pictureBox9.Location = new Point(-191, 474);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(0, 0);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 10;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Group_237476;
            pictureBox10.Location = new Point(450, 462);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(177, 214);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 11;
            pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = Properties.Resources.Rectangle_1178;
            pictureBox11.Location = new Point(783, 645);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(792, 250);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 12;
            pictureBox11.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(436, 878);
            label1.Name = "label1";
            label1.Size = new Size(245, 33);
            label1.TabIndex = 13;
            label1.Text = "Ulasan Tentang Buku";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(436, 910);
            label3.Name = "label3";
            label3.Size = new Size(944, 32);
            label3.TabIndex = 14;
            label3.Text = "_____________________________________________________________________________________________";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Nunito", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.Location = new Point(651, 473);
            label4.Name = "label4";
            label4.Size = new Size(280, 44);
            label4.TabIndex = 15;
            label4.Text = "Follow You Home";
            // 
            // pictureBox12
            // 
            pictureBox12.Image = Properties.Resources.Group_237477;
            pictureBox12.Location = new Point(947, 484);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(84, 42);
            pictureBox12.TabIndex = 16;
            pictureBox12.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(665, 538);
            label5.Name = "label5";
            label5.Size = new Size(57, 33);
            label5.TabIndex = 17;
            label5.Text = "001";
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Highlight;
            button1.Font = new Font("Nunito", 8.999998F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Location = new Point(1673, 952);
            button1.Name = "button1";
            button1.Size = new Size(224, 65);
            button1.TabIndex = 18;
            button1.Text = "Next";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Nunito", 7.124999F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(665, 571);
            label6.Name = "label6";
            label6.Size = new Size(100, 26);
            label6.TabIndex = 19;
            label6.Text = "Rak L3-01";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(813, 564);
            label7.Name = "label7";
            label7.Size = new Size(1084, 33);
            label7.TabIndex = 20;
            label7.Text = " It was supposed to be the trip of a lifetime, a final adventure before settling down. Selengkapnya... ";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.ButtonHighlight;
            label8.Location = new Point(813, 668);
            label8.Name = "label8";
            label8.Size = new Size(108, 32);
            label8.TabIndex = 21;
            label8.Text = "Daftar Isi";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.ButtonHighlight;
            label9.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(813, 731);
            label9.Name = "label9";
            label9.Size = new Size(128, 33);
            label9.TabIndex = 22;
            label9.Text = "Pengantar";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = SystemColors.ButtonHighlight;
            label10.Location = new Point(813, 764);
            label10.Name = "label10";
            label10.Size = new Size(83, 32);
            label10.TabIndex = 23;
            label10.Text = "Prolog";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = SystemColors.ButtonHighlight;
            label11.Location = new Point(813, 796);
            label11.Name = "label11";
            label11.Size = new Size(222, 32);
            label11.TabIndex = 24;
            label11.Text = "Chapter 1 - Collage";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = SystemColors.ButtonHighlight;
            label12.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(1473, 668);
            label12.Name = "label12";
            label12.Size = new Size(53, 33);
            label12.TabIndex = 25;
            label12.Text = "Hal";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = SystemColors.ButtonHighlight;
            label13.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.Location = new Point(1488, 722);
            label13.Name = "label13";
            label13.Size = new Size(29, 33);
            label13.TabIndex = 26;
            label13.Text = "1";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = SystemColors.ButtonHighlight;
            label14.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.Location = new Point(1488, 755);
            label14.Name = "label14";
            label14.Size = new Size(29, 33);
            label14.TabIndex = 27;
            label14.Text = "3";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = SystemColors.ButtonHighlight;
            label15.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label15.Location = new Point(1488, 788);
            label15.Name = "label15";
            label15.Size = new Size(29, 33);
            label15.TabIndex = 28;
            label15.Text = "4";
            // 
            // pictureBox13
            // 
            pictureBox13.Image = Properties.Resources.Rectangle_1189;
            pictureBox13.Location = new Point(450, 952);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(345, 87);
            pictureBox13.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox13.TabIndex = 29;
            pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            pictureBox14.BackColor = SystemColors.ButtonHighlight;
            pictureBox14.Image = Properties.Resources.Ellipse_12;
            pictureBox14.Location = new Point(470, 973);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(67, 66);
            pictureBox14.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox14.TabIndex = 30;
            pictureBox14.TabStop = false;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = SystemColors.ButtonHighlight;
            label16.Font = new Font("Nunito", 7.124999F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label16.Location = new Point(543, 968);
            label16.Name = "label16";
            label16.Size = new Size(220, 26);
            label16.TabIndex = 31;
            label16.Text = "Muhammad Rizal Satria ";
            label16.Click += label16_Click;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = SystemColors.ButtonHighlight;
            label17.Font = new Font("Nunito", 6F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label17.ForeColor = SystemColors.ControlText;
            label17.Location = new Point(543, 1005);
            label17.Name = "label17";
            label17.Size = new Size(174, 22);
            label17.TabIndex = 32;
            label17.Text = "Bukunya Sangat seru...";
            // 
            // Tambah_Buku
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1920, 1080);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(pictureBox14);
            Controls.Add(pictureBox13);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(pictureBox12);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox9);
            Controls.Add(label2);
            Controls.Add(Jamaludin);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Tambah_Buku";
            Text = "Tambah_Buku";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private Label Jamaludin;
        private Label label2;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private Label label1;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox12;
        private Label label5;
        private Button button1;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private PictureBox pictureBox13;
        private PictureBox pictureBox14;
        private Label label16;
        private Label label17;
    }
}