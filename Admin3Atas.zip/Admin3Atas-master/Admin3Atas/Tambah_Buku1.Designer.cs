﻿namespace Admin3Atas
{
    partial class Tambah_Buku1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.Highlight;
            pictureBox1.Dock = DockStyle.Left;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(418, 1080);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Dock = DockStyle.Top;
            pictureBox2.Image = Properties.Resources.Mask_group;
            pictureBox2.Location = new Point(418, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1502, 428);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = SystemColors.Highlight;
            pictureBox3.Image = Properties.Resources.Vector;
            pictureBox3.Location = new Point(80, 41);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(245, 179);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Frame_10;
            pictureBox4.Location = new Point(34, 834);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(344, 61);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 3;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Frame_11;
            pictureBox5.Location = new Point(34, 353);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(344, 61);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 4;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Frame_15;
            pictureBox6.Location = new Point(34, 916);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(344, 61);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 5;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.Frame_17;
            pictureBox7.Location = new Point(34, 443);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(344, 61);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 6;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.Group_237503;
            pictureBox8.Location = new Point(34, 538);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(344, 61);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 7;
            pictureBox8.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Highlight;
            label1.Font = new Font("Nunito", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(116, 246);
            label1.Name = "label1";
            label1.Size = new Size(169, 44);
            label1.TabIndex = 8;
            label1.Text = "Jamaludin";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.Highlight;
            label2.Font = new Font("Nunito", 7.124999F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(96, 290);
            label2.Name = "label2";
            label2.Size = new Size(200, 26);
            label2.TabIndex = 9;
            label2.Text = "jamaludin@gamil.com";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Nunito", 8.999998F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(447, 443);
            label3.Name = "label3";
            label3.Size = new Size(168, 33);
            label3.TabIndex = 10;
            label3.Text = "Tambah Buku";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(447, 520);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(1401, 39);
            textBox1.TabIndex = 11;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(447, 603);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(1401, 39);
            textBox2.TabIndex = 12;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(447, 685);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(1401, 39);
            textBox3.TabIndex = 13;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(447, 760);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(1401, 39);
            textBox4.TabIndex = 14;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(447, 847);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(1401, 39);
            textBox5.TabIndex = 15;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(447, 927);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(1401, 39);
            textBox6.TabIndex = 16;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(447, 484);
            label4.Name = "label4";
            label4.Size = new Size(140, 33);
            label4.TabIndex = 17;
            label4.Text = "Nama Buku";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(447, 562);
            label5.Name = "label5";
            label5.Size = new Size(107, 33);
            label5.TabIndex = 18;
            label5.Text = "Sinopsis";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(447, 650);
            label6.Name = "label6";
            label6.Size = new Size(95, 33);
            label6.TabIndex = 19;
            label6.Text = "Penulis";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(447, 727);
            label7.Name = "label7";
            label7.Size = new Size(107, 33);
            label7.TabIndex = 20;
            label7.Text = "Penerbit";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(447, 811);
            label8.Name = "label8";
            label8.Size = new Size(149, 33);
            label8.TabIndex = 21;
            label8.Text = "Tahun Terbit";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Nunito", 8.999998F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(452, 891);
            label9.Name = "label9";
            label9.Size = new Size(68, 33);
            label9.TabIndex = 22;
            label9.Text = "Jenis";
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Highlight;
            button1.Font = new Font("Nunito", 8.999998F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(1065, 983);
            button1.Name = "button1";
            button1.Size = new Size(247, 46);
            button1.TabIndex = 23;
            button1.Text = "Upload";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Tambah_Buku1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1920, 1080);
            Controls.Add(button1);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Tambah_Buku1";
            Text = "Tambah_Buku1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Button button1;
    }
}