﻿namespace hmpg
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            label2 = new Label();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox5 = new PictureBox();
            label3 = new Label();
            label4 = new Label();
            pictureBox8 = new PictureBox();
            label5 = new Label();
            label6 = new Label();
            pictureBox9 = new PictureBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            pictureBox10 = new PictureBox();
            label13 = new Label();
            pictureBox11 = new PictureBox();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            pictureBox12 = new PictureBox();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(pictureBox7);
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Font = new Font("Nunito SemiBold", 9.999999F, FontStyle.Bold);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(418, 1024);
            panel1.TabIndex = 0;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.Frame_19;
            pictureBox7.Location = new Point(36, 849);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(336, 67);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 7;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Frame_15;
            pictureBox6.Location = new Point(36, 922);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(336, 76);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 6;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Nunito SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.Control;
            label2.Location = new Point(109, 328);
            label2.Name = "label2";
            label2.Size = new Size(193, 24);
            label2.TabIndex = 5;
            label2.Text = "jamaludin@gmail.com";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Frame_19__2_;
            pictureBox4.Location = new Point(36, 548);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(336, 72);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 4;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Frame_11;
            pictureBox3.Location = new Point(36, 465);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(336, 77);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nunito", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(143, 295);
            label1.Name = "label1";
            label1.Size = new Size(126, 33);
            label1.TabIndex = 2;
            label1.Text = "Jamaludin";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Frame_17;
            pictureBox2.Location = new Point(36, 383);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(336, 91);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Ellipse_11;
            pictureBox1.Location = new Point(80, 68);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(252, 210);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Dock = DockStyle.Top;
            pictureBox5.Image = Properties.Resources._20912_1__1_;
            pictureBox5.Location = new Point(418, 0);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(1480, 422);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 1;
            pictureBox5.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Nunito ExtraBold", 13.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(445, 25);
            label3.Name = "label3";
            label3.Size = new Size(241, 38);
            label3.TabIndex = 2;
            label3.Text = "Selamat Datang,";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Nunito ExtraBold", 13.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(445, 77);
            label4.Name = "label4";
            label4.Size = new Size(152, 38);
            label4.TabIndex = 3;
            label4.Text = "Jamaludin";
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.Group_237534;
            pictureBox8.Location = new Point(614, 428);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(1075, 63);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 4;
            pictureBox8.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.LightGray;
            label5.Font = new Font("Nunito", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DimGray;
            label5.Location = new Point(683, 446);
            label5.Name = "label5";
            label5.Size = new Size(188, 28);
            label5.TabIndex = 5;
            label5.Text = "Nama Buku, Genre";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Nunito", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(458, 514);
            label6.Name = "label6";
            label6.Size = new Size(139, 28);
            label6.TabIndex = 6;
            label6.Text = "Rekomendasi";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.Group_24;
            pictureBox9.Location = new Point(445, 548);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(186, 215);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 7;
            pictureBox9.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Nunito ExtraBold", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(665, 548);
            label7.Name = "label7";
            label7.Size = new Size(183, 28);
            label7.TabIndex = 8;
            label7.Text = "Follow You Home";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Nunito SemiBold", 9.999999F, FontStyle.Bold);
            label8.Location = new Point(668, 595);
            label8.Name = "label8";
            label8.Size = new Size(461, 112);
            label8.TabIndex = 9;
            label8.Text = "Ini seharusnya menjadi perjalanan seumur hidup,\r\npetualangan terakhir sebelum menetap. Namun\r\nsetelah awal yang sempurna, pertemuan dengan\r\npasangan muda di kereta malam... Read More";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Lime;
            label9.Font = new Font("Nunito", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = SystemColors.Control;
            label9.Location = new Point(668, 719);
            label9.Name = "label9";
            label9.Size = new Size(91, 28);
            label9.TabIndex = 10;
            label9.Text = "Tersedia";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Nunito ExtraBold", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(1381, 551);
            label10.Name = "label10";
            label10.Size = new Size(200, 28);
            label10.TabIndex = 11;
            label10.Text = "The House Mystery";
            label10.Click += label10_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Nunito SemiBold", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(1381, 595);
            label11.Name = "label11";
            label11.Size = new Size(494, 112);
            label11.TabIndex = 12;
            label11.Text = "Bapak-Bapak, Ibu-Ibu, dan Anak-Anak sekalian,\r\nmendekatlah! Jangan malu-malu! Kami memiliki\r\nkoleksi terbesar barang-barang absurd dan pameran\r\nmenakjubkan yang berisi lebih dari set... Read More";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Red;
            label12.Font = new Font("Nunito", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = SystemColors.Control;
            label12.Location = new Point(1381, 719);
            label12.Name = "label12";
            label12.Size = new Size(148, 28);
            label12.TabIndex = 13;
            label12.Text = "Tidak Tersedia";
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Group_32;
            pictureBox10.Location = new Point(1170, 548);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(184, 212);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 14;
            pictureBox10.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Nunito", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(458, 766);
            label13.Name = "label13";
            label13.Size = new Size(86, 28);
            label13.TabIndex = 15;
            label13.Text = "Populer";
            // 
            // pictureBox11
            // 
            pictureBox11.Image = Properties.Resources.Group_24;
            pictureBox11.Location = new Point(445, 816);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(186, 200);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 16;
            pictureBox11.TabStop = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Nunito ExtraBold", 9.999999F, FontStyle.Bold);
            label14.Location = new Point(668, 816);
            label14.Name = "label14";
            label14.Size = new Size(183, 28);
            label14.TabIndex = 17;
            label14.Text = "Follow You Home";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Nunito SemiBold", 9.999999F, FontStyle.Bold);
            label15.Location = new Point(668, 863);
            label15.Name = "label15";
            label15.Size = new Size(461, 112);
            label15.TabIndex = 18;
            label15.Text = "Ini seharusnya menjadi perjalanan seumur hidup,\r\npetualangan terakhir sebelum menetap. Namun\r\nsetelah awal yang sempurna, pertemuan dengan\r\npasangan muda di kereta malam... Read More\r\n";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.Red;
            label16.Font = new Font("Nunito", 9.999999F, FontStyle.Bold);
            label16.ForeColor = SystemColors.Control;
            label16.Location = new Point(668, 990);
            label16.Name = "label16";
            label16.Size = new Size(148, 28);
            label16.TabIndex = 19;
            label16.Text = "Tidak Tersedia";
            // 
            // pictureBox12
            // 
            pictureBox12.Image = Properties.Resources.Group_32;
            pictureBox12.Location = new Point(1172, 799);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(182, 217);
            pictureBox12.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox12.TabIndex = 20;
            pictureBox12.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Nunito ExtraBold", 9.999999F, FontStyle.Bold);
            label17.Location = new Point(1381, 799);
            label17.Name = "label17";
            label17.Size = new Size(200, 28);
            label17.TabIndex = 21;
            label17.Text = "The House Mystery";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Nunito SemiBold", 9.999999F, FontStyle.Bold);
            label18.Location = new Point(1381, 863);
            label18.Name = "label18";
            label18.Size = new Size(494, 112);
            label18.TabIndex = 22;
            label18.Text = "Bapak-Bapak, Ibu-Ibu, dan Anak-Anak sekalian,\r\nmendekatlah! Jangan malu-malu! Kami memiliki\r\nkoleksi terbesar barang-barang absurd dan pameran\r\nmenakjubkan yang berisi lebih dari set... Read More\r\n";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.Lime;
            label19.Font = new Font("Nunito", 9.999999F, FontStyle.Bold);
            label19.ForeColor = SystemColors.Control;
            label19.Location = new Point(1381, 990);
            label19.Name = "label19";
            label19.Size = new Size(91, 28);
            label19.TabIndex = 23;
            label19.Text = "Tersedia";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1898, 1024);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(pictureBox12);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(pictureBox11);
            Controls.Add(label13);
            Controls.Add(pictureBox10);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(pictureBox9);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(pictureBox8);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(pictureBox5);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private Label label2;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Label label1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox5;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox8;
        private Label label5;
        private Label label6;
        private PictureBox pictureBox9;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private PictureBox pictureBox10;
        private Label label13;
        private PictureBox pictureBox11;
        private Label label14;
        private Label label15;
        private Label label16;
        private PictureBox pictureBox12;
        private Label label17;
        private Label label18;
        private Label label19;
    }
}
