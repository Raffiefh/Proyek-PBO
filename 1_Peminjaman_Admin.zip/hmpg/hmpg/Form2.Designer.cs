﻿namespace hmpg
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            panel1 = new Panel();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            label3 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            label9 = new Label();
            pictureBox11 = new PictureBox();
            pictureBox12 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            button1 = new Button();
            button2 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Font = new Font("Nunito SemiBold", 8.999999F, FontStyle.Bold);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(418, 1024);
            panel1.TabIndex = 0;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Frame_15;
            pictureBox6.Location = new Point(30, 937);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(342, 75);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 7;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Frame_19;
            pictureBox5.Location = new Point(30, 850);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(342, 77);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 6;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Frame_19__2_;
            pictureBox4.Location = new Point(30, 587);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(342, 71);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 5;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Frame_11;
            pictureBox3.Location = new Point(30, 507);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(342, 74);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 4;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Frame_17;
            pictureBox2.Location = new Point(30, 425);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(342, 76);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Nunito", 9.999999F, FontStyle.Bold);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(109, 331);
            label2.Name = "label2";
            label2.Size = new Size(221, 28);
            label2.TabIndex = 2;
            label2.Text = "Jamaludin@gmail.com";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nunito", 9.999999F, FontStyle.Bold);
            label1.Location = new Point(163, 295);
            label1.Name = "label1";
            label1.Size = new Size(95, 28);
            label1.TabIndex = 1;
            label1.Text = "Jamludin";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Ellipse_11;
            pictureBox1.Location = new Point(74, 45);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(257, 237);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Dock = DockStyle.Top;
            pictureBox7.Image = Properties.Resources.Rectangle_1177;
            pictureBox7.Location = new Point(418, 0);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(1480, 390);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 1;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = SystemColors.Menu;
            pictureBox8.Image = Properties.Resources.Group_241;
            pictureBox8.Location = new Point(1009, 230);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(236, 223);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 2;
            pictureBox8.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Nunito ExtraBold", 9.999999F, FontStyle.Bold);
            label3.Location = new Point(1035, 456);
            label3.Name = "label3";
            label3.Size = new Size(183, 28);
            label3.TabIndex = 3;
            label3.Text = "Follow You Home";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Nunito ExtraBold", 9.999999F, FontStyle.Bold);
            label5.Location = new Point(454, 556);
            label5.Name = "label5";
            label5.Size = new Size(99, 28);
            label5.TabIndex = 5;
            label5.Text = "Deskripsi";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Nunito SemiBold", 9.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(454, 596);
            label6.Name = "label6";
            label6.Size = new Size(1354, 112);
            label6.TabIndex = 6;
            label6.Text = resources.GetString("label6.Text");
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ActiveBorder;
            label7.Font = new Font("Nunito", 9.999999F, FontStyle.Bold);
            label7.Location = new Point(454, 750);
            label7.Name = "label7";
            label7.Size = new Size(79, 28);
            label7.TabIndex = 7;
            label7.Text = "#Horor";
            label7.Click += label7_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Nunito ExtraBold", 9.999999F, FontStyle.Bold);
            label8.Location = new Point(454, 788);
            label8.Name = "label8";
            label8.Size = new Size(217, 28);
            label8.TabIndex = 8;
            label8.Text = "Ulasan Tentang Buku";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.Rectangle_1189;
            pictureBox9.Location = new Point(735, 869);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(381, 104);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 9;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Rectangle_1189;
            pictureBox10.Location = new Point(1152, 869);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(381, 104);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 10;
            pictureBox10.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.White;
            label9.Font = new Font("Nunito", 9.999999F, FontStyle.Bold);
            label9.Location = new Point(843, 887);
            label9.Name = "label9";
            label9.Size = new Size(173, 28);
            label9.TabIndex = 11;
            label9.Text = "Mohammad Rizal";
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.White;
            pictureBox11.Image = Properties.Resources.Ellipse_11;
            pictureBox11.Location = new Point(758, 887);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(79, 64);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 12;
            pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.White;
            pictureBox12.Image = Properties.Resources.Ellipse_11;
            pictureBox12.Location = new Point(1171, 887);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(79, 64);
            pictureBox12.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox12.TabIndex = 13;
            pictureBox12.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.White;
            label10.Font = new Font("Nunito SemiBold", 8.999999F, FontStyle.Bold);
            label10.Location = new Point(843, 926);
            label10.Name = "label10";
            label10.Size = new Size(138, 24);
            label10.TabIndex = 14;
            label10.Text = "Serem bukunya";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.White;
            label11.Font = new Font("Nunito", 9.999999F, FontStyle.Bold);
            label11.Location = new Point(1256, 887);
            label11.Name = "label11";
            label11.Size = new Size(173, 28);
            label11.TabIndex = 15;
            label11.Text = "Mohammad Rizal";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.White;
            label12.Font = new Font("Nunito SemiBold", 8.999999F, FontStyle.Bold);
            label12.Location = new Point(1256, 926);
            label12.Name = "label12";
            label12.Size = new Size(145, 24);
            label12.TabIndex = 16;
            label12.Text = "Bukunya baguss";
            // 
            // button1
            // 
            button1.Location = new Point(441, 24);
            button1.Name = "button1";
            button1.Size = new Size(35, 34);
            button1.TabIndex = 17;
            button1.Text = "<";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Highlight;
            button2.Font = new Font("Nunito", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(1062, 496);
            button2.Name = "button2";
            button2.Size = new Size(135, 47);
            button2.TabIndex = 18;
            button2.Text = "Pinjam";
            button2.UseVisualStyleBackColor = false;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1898, 1024);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox11);
            Controls.Add(label9);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(panel1);
            Name = "Form2";
            Text = "Form2";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private Label label3;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private Label label9;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private Label label10;
        private Label label11;
        private Label label12;
        private Button button1;
        private Button button2;
    }
}