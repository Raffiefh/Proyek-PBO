﻿namespace Ifran_Raffi
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            groupBox1 = new GroupBox();
            label8 = new Label();
            bigLabel1 = new ReaLTaiizor.Controls.BigLabel();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            pictureBox9 = new PictureBox();
            groupBox2 = new GroupBox();
            pictureBox12 = new PictureBox();
            panel3 = new Panel();
            button3 = new Button();
            label29 = new Label();
            label28 = new Label();
            label18 = new Label();
            label25 = new Label();
            label24 = new Label();
            label23 = new Label();
            label22 = new Label();
            pictureBox11 = new PictureBox();
            panel2 = new Panel();
            button2 = new Button();
            label27 = new Label();
            label19 = new Label();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label9 = new Label();
            pictureBox10 = new PictureBox();
            groupBox3 = new GroupBox();
            button1 = new Button();
            label26 = new Label();
            label13 = new Label();
            label14 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            pictureBox8 = new PictureBox();
            label20 = new Label();
            label21 = new Label();
            nightControlBox1 = new ReaLTaiizor.Controls.NightControlBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(pictureBox7);
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(408, 1033);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.Frame_15;
            pictureBox7.Location = new Point(32, 906);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(344, 62);
            pictureBox7.TabIndex = 7;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Frame_10;
            pictureBox6.Location = new Point(32, 812);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(344, 61);
            pictureBox6.TabIndex = 6;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Group_237504;
            pictureBox5.Location = new Point(32, 527);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(344, 61);
            pictureBox5.TabIndex = 5;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Frame_17;
            pictureBox4.Location = new Point(32, 435);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(344, 61);
            pictureBox4.TabIndex = 4;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Frame_11;
            pictureBox3.Location = new Point(32, 335);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(344, 61);
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonFace;
            label2.Location = new Point(134, 277);
            label2.Name = "label2";
            label2.Size = new Size(162, 20);
            label2.TabIndex = 2;
            label2.Text = "jamaludin@gmail.com";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(163, 249);
            label1.Name = "label1";
            label1.Size = new Size(104, 28);
            label1.TabIndex = 1;
            label1.Text = "Jamaludin";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Vector;
            pictureBox2.Location = new Point(116, 44);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(194, 180);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Image = Properties.Resources._20912_1;
            pictureBox1.Location = new Point(408, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1494, 287);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label3.Location = new Point(32, 10);
            label3.Name = "label3";
            label3.Size = new Size(125, 28);
            label3.TabIndex = 2;
            label3.Text = "Daftar buku:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(bigLabel1);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(pictureBox9);
            groupBox1.Controls.Add(label3);
            groupBox1.Location = new Point(408, 293);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1494, 107);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ControlDark;
            label8.Location = new Point(871, 80);
            label8.Name = "label8";
            label8.Size = new Size(46, 23);
            label8.TabIndex = 10;
            label8.Text = "Date";
            // 
            // bigLabel1
            // 
            bigLabel1.AutoSize = true;
            bigLabel1.BackColor = Color.Transparent;
            bigLabel1.Font = new Font("Segoe UI", 25F);
            bigLabel1.ForeColor = Color.FromArgb(80, 80, 80);
            bigLabel1.Location = new Point(880, 100);
            bigLabel1.Name = "bigLabel1";
            bigLabel1.Size = new Size(206, 57);
            bigLabel1.TabIndex = 9;
            bigLabel1.Text = "bigLabel1";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlDark;
            label7.Location = new Point(623, 81);
            label7.Name = "label7";
            label7.Size = new Size(44, 23);
            label7.TabIndex = 8;
            label7.Text = "Stok";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ControlDark;
            label6.Location = new Point(400, 81);
            label6.Name = "label6";
            label6.Size = new Size(47, 23);
            label6.TabIndex = 7;
            label6.Text = "Jenis";
            label6.Click += label6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlDark;
            label5.Location = new Point(157, 81);
            label5.Name = "label5";
            label5.Size = new Size(95, 23);
            label5.TabIndex = 6;
            label5.Text = "Judul Buku";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.LightGray;
            label4.Location = new Point(47, 45);
            label4.Name = "label4";
            label4.Size = new Size(71, 20);
            label4.TabIndex = 5;
            label4.Text = "Cari buku";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.LightGray;
            textBox1.ForeColor = SystemColors.InfoText;
            textBox1.Location = new Point(157, 42);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(997, 27);
            textBox1.TabIndex = 5;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.Rectangle_1188;
            pictureBox9.Location = new Point(32, 41);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(1192, 30);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 3;
            pictureBox9.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(pictureBox12);
            groupBox2.Controls.Add(panel3);
            groupBox2.Controls.Add(panel2);
            groupBox2.Controls.Add(groupBox3);
            groupBox2.Location = new Point(410, 400);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(1492, 633);
            groupBox2.TabIndex = 6;
            groupBox2.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = Properties.Resources.Frame_19;
            pictureBox12.Location = new Point(1105, 519);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(332, 49);
            pictureBox12.TabIndex = 3;
            pictureBox12.TabStop = false;
            pictureBox12.Click += pictureBox12_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(button3);
            panel3.Controls.Add(label29);
            panel3.Controls.Add(label28);
            panel3.Controls.Add(label18);
            panel3.Controls.Add(label25);
            panel3.Controls.Add(label24);
            panel3.Controls.Add(label23);
            panel3.Controls.Add(label22);
            panel3.Controls.Add(pictureBox11);
            panel3.Location = new Point(6, 186);
            panel3.Name = "panel3";
            panel3.RightToLeft = RightToLeft.Yes;
            panel3.Size = new Size(1478, 78);
            panel3.TabIndex = 2;
            panel3.Paint += panel3_Paint;
            // 
            // button3
            // 
            button3.BackColor = Color.OrangeRed;
            button3.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = SystemColors.ButtonHighlight;
            button3.Location = new Point(1122, 16);
            button3.Name = "button3";
            button3.Size = new Size(105, 39);
            button3.TabIndex = 9;
            button3.Text = "Hapus";
            button3.UseVisualStyleBackColor = false;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label29.Location = new Point(894, 30);
            label29.Name = "label29";
            label29.Size = new Size(15, 20);
            label29.TabIndex = 8;
            label29.Text = "-";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label28.Location = new Point(1385, 25);
            label28.Name = "label28";
            label28.Size = new Size(17, 28);
            label28.TabIndex = 7;
            label28.Text = ":";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.Location = new Point(841, 37);
            label18.Name = "label18";
            label18.Size = new Size(0, 23);
            label18.TabIndex = 6;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label25.Location = new Point(631, 28);
            label25.Name = "label25";
            label25.Size = new Size(19, 23);
            label25.TabIndex = 4;
            label25.Text = "3";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label24.Location = new Point(392, 25);
            label24.Name = "label24";
            label24.Size = new Size(55, 23);
            label24.TabIndex = 3;
            label24.Text = "Novel";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label23.ForeColor = SystemColors.ControlDark;
            label23.Location = new Point(153, 42);
            label23.Name = "label23";
            label23.Size = new Size(65, 23);
            label23.TabIndex = 2;
            label23.Text = "#44512";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label22.Location = new Point(153, 16);
            label22.Name = "label22";
            label22.Size = new Size(135, 23);
            label22.TabIndex = 1;
            label22.Text = "The cloudy skies";
            // 
            // pictureBox11
            // 
            pictureBox11.Image = Properties.Resources.Vector;
            pictureBox11.Location = new Point(63, 16);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(49, 49);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 0;
            pictureBox11.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(button2);
            panel2.Controls.Add(label27);
            panel2.Controls.Add(label19);
            panel2.Controls.Add(label17);
            panel2.Controls.Add(label16);
            panel2.Controls.Add(label15);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(pictureBox10);
            panel2.Location = new Point(6, 102);
            panel2.Name = "panel2";
            panel2.Size = new Size(1478, 78);
            panel2.TabIndex = 1;
            // 
            // button2
            // 
            button2.BackColor = Color.OrangeRed;
            button2.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.ButtonHighlight;
            button2.Location = new Point(1122, 15);
            button2.Name = "button2";
            button2.Size = new Size(105, 38);
            button2.TabIndex = 7;
            button2.Text = "Hapus";
            button2.UseVisualStyleBackColor = false;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label27.Location = new Point(1385, 20);
            label27.Name = "label27";
            label27.Size = new Size(17, 28);
            label27.TabIndex = 6;
            label27.Text = ":";
            label27.Click += label27_Click;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label19.Location = new Point(843, 25);
            label19.Name = "label19";
            label19.Size = new Size(110, 23);
            label19.TabIndex = 5;
            label19.Text = "02 April 2024";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.Location = new Point(631, 19);
            label17.Name = "label17";
            label17.Size = new Size(19, 23);
            label17.TabIndex = 4;
            label17.Text = "3";
            label17.Click += label17_Click;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.Location = new Point(392, 19);
            label16.Name = "label16";
            label16.Size = new Size(55, 23);
            label16.TabIndex = 3;
            label16.Text = "Novel";
            label16.Click += label16_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.FlatStyle = FlatStyle.System;
            label15.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = SystemColors.ControlDark;
            label15.Location = new Point(154, 41);
            label15.Name = "label15";
            label15.Size = new Size(56, 20);
            label15.TabIndex = 2;
            label15.Text = "#31266";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(153, 15);
            label9.Name = "label9";
            label9.Size = new Size(143, 23);
            label9.TabIndex = 1;
            label9.Text = "Follow you home";
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Vector;
            pictureBox10.Location = new Point(63, 15);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(51, 46);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 0;
            pictureBox10.TabStop = false;
            pictureBox10.Click += pictureBox10_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(button1);
            groupBox3.Controls.Add(label26);
            groupBox3.Controls.Add(label13);
            groupBox3.Controls.Add(label14);
            groupBox3.Controls.Add(label12);
            groupBox3.Controls.Add(label11);
            groupBox3.Controls.Add(label10);
            groupBox3.Controls.Add(pictureBox8);
            groupBox3.Location = new Point(6, 18);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(1474, 78);
            groupBox3.TabIndex = 0;
            groupBox3.TabStop = false;
            groupBox3.Enter += groupBox3_Enter;
            // 
            // button1
            // 
            button1.BackColor = Color.OrangeRed;
            button1.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(1122, 26);
            button1.Name = "button1";
            button1.Size = new Size(105, 40);
            button1.TabIndex = 8;
            button1.Text = "Hapus";
            button1.UseVisualStyleBackColor = false;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label26.Location = new Point(1385, 30);
            label26.Name = "label26";
            label26.Size = new Size(17, 28);
            label26.TabIndex = 7;
            label26.Text = ":";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(149, 23);
            label13.Name = "label13";
            label13.Size = new Size(154, 23);
            label13.TabIndex = 6;
            label13.Text = "The House mistery";
            label13.Click += label13_Click;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(631, 23);
            label14.Name = "label14";
            label14.Size = new Size(19, 23);
            label14.TabIndex = 5;
            label14.Text = "3";
            label14.Click += label14_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(845, 23);
            label12.Name = "label12";
            label12.Size = new Size(108, 23);
            label12.TabIndex = 4;
            label12.Text = "17 April 2024";
            label12.Click += label12_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(392, 23);
            label11.Name = "label11";
            label11.Size = new Size(55, 23);
            label11.TabIndex = 3;
            label11.Text = "Novel";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = SystemColors.ControlDark;
            label10.Location = new Point(149, 49);
            label10.Name = "label10";
            label10.Size = new Size(61, 23);
            label10.TabIndex = 2;
            label10.Text = "#31125";
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.Vector;
            pictureBox8.Location = new Point(59, 17);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(51, 49);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 0;
            pictureBox8.TabStop = false;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.Location = new Point(455, 23);
            label20.Name = "label20";
            label20.Size = new Size(182, 31);
            label20.TabIndex = 11;
            label20.Text = "Selamat datang,";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label21.Location = new Point(455, 70);
            label21.Name = "label21";
            label21.Size = new Size(104, 28);
            label21.TabIndex = 8;
            label21.Text = "Jamaludin";
            // 
            // nightControlBox1
            // 
            nightControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            nightControlBox1.BackColor = Color.Transparent;
            nightControlBox1.CloseHoverColor = Color.FromArgb(199, 80, 80);
            nightControlBox1.CloseHoverForeColor = Color.White;
            nightControlBox1.DefaultLocation = true;
            nightControlBox1.DisableMaximizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.DisableMinimizeColor = Color.FromArgb(105, 105, 105);
            nightControlBox1.EnableCloseColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMaximizeButton = true;
            nightControlBox1.EnableMaximizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.EnableMinimizeButton = true;
            nightControlBox1.EnableMinimizeColor = Color.FromArgb(160, 160, 160);
            nightControlBox1.Location = new Point(1781, 0);
            nightControlBox1.MaximizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MaximizeHoverForeColor = Color.White;
            nightControlBox1.MinimizeHoverColor = Color.FromArgb(15, 255, 255, 255);
            nightControlBox1.MinimizeHoverForeColor = Color.White;
            nightControlBox1.Name = "nightControlBox1";
            nightControlBox1.Size = new Size(139, 31);
            nightControlBox1.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1902, 1033);
            ControlBox = false;
            Controls.Add(nightControlBox1);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Label label3;
        private GroupBox groupBox1;
        private PictureBox pictureBox9;
        private Label label4;
        private TextBox textBox1;
        private Label label5;
        private Label label6;
        private Label label8;
        private ReaLTaiizor.Controls.BigLabel bigLabel1;
        private Label label7;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private Label label14;
        private Label label12;
        private Label label11;
        private Label label10;
        private PictureBox pictureBox8;
        private Label label13;
        private Panel panel2;
        private PictureBox pictureBox10;
        private Panel panel3;
        private Label label19;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label9;
        private PictureBox pictureBox11;
        private Label label25;
        private Label label24;
        private Label label23;
        private Label label22;
        private Label label28;
        private Label label18;
        private Label label27;
        private Label label26;
        private Label label29;
        private Label label20;
        private Label label21;
        private PictureBox pictureBox12;
        private Button button3;
        private Button button2;
        private Button button1;
        private ReaLTaiizor.Controls.NightControlBox nightControlBox1;
    }
}
